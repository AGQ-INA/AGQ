# AGQ example

To let user fully experience the whole progress of INA, we give a runtime example of AGQ with the Python library **Scapy**. The server clients need to send INA packtes, receive aggregated results and send ACKs. See details in the corresonding directory.